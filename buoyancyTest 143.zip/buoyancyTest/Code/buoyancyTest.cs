﻿using UnityEngine;

namespace buoyancyTest
{
    public class ModuleBuoyancyTest : PartModule
    {
        [KSPField(guiActive = true, guiActiveEditor = true,guiName = "Buoyancy", isPersistant = true),
         UI_FloatRange(maxValue = 5, minValue = -5, stepIncrement = 0.01f, requireFullControl = false)]
        protected float buoyancy = 0.0f;

        public override void OnStart(StartState state)
        {
            Fields["buoyancy"].OnValueModified += UpdateBuoyancy;
        }

        public void OnDisable()
        {
            Fields["buoyancy"].OnValueModified -= UpdateBuoyancy;
        }

        private void UpdateBuoyancy(object o)
        {
            part.buoyancy = buoyancy;
            Debug.Log("Adjust");
        }

    }
}
